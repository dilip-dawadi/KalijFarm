https://kalijfarm.herokuapp.com/kalijs?userPage=1

# {Dilip Dawadi - Softwarica College}

# Before you start

https://lwinmoepaing.github.io/generator.html#
Create .env file in main folder
CONNECTION_URL = mongodb+srv://................
PORT = 5000. or ....
